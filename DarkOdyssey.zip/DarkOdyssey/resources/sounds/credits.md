## Audio Credits 

snd_default_bkg, 428858__supervanz__duskwalkin_loop.wav, CC0  
snd_default_bkg_2, PatreonGoalRewardLoops-Track10-Layer_04.wav Track by Abstraction (http://abstractionmusic.bandcamp.com/). See license in this folder.  
snd_boss_bkg, 198415__divinux__ambientdanger.wav, CC0  
snd_bullet_fire, 697730__sustainededed__small-laser.mp3, CC BY 4.0  
snd_bullet_hit, 319226__worthahep88__single-rock-hitting-wood.wav, CC0  
snd_bullet_hit, 516073__logicogonist__kick-mystic-1b.wav, CC0
snd_explosion, 536548__cascoes__explosion.wav, CC0  
snd_collision, 391658__jeckkech__collision, CC0  
snd_asteroid_destroyed, 546957__sieuamthanh__nolonduoinuoc1.wav, CC0  
snd_powerup_spawn, 657938__matrixxx__scifi-popup-warning-notice-or-note.wav, CC0  
snd_powerup_spawn, 569679__marokki__plop-effect.wav, CC0  
snd_powerup_pickup, 523649__matrixxx__powerup-07.wav, CC0  
snd_powerup_pickup, 325805__wagna__collect.wav, CC0  
snd_win, 341984__unadamlar__winning.wav, CC0  
snd_gameover, gameover.wav, Copyright Kranthi Yanamandra, CC BY 4.0  
snd_darkmatter_collide, 455215__matrixxx__cartoon-stunned-02.wav, CC0  
snd_darkmatter_collide, 95952__tmokonen__zap.wav, CC BY 4.0  

### See licences here
CC BY 4.0  
https://creativecommons.org/licenses/by/4.0/  

CC0  
https://creativecommons.org/publicdomain/zero/1.0/  
